#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer

class AuthHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        
        self.send_response(200)
        
        if 'password' in post_data:
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"MFA Required. Please submit your TOTP code.")
            print("[SERVER] Da nhan Username/Password. Yeu cau MFA.")
        
        elif 'mfa_code' in post_data:
            self.send_header('Set-Cookie', 'SessionID=SECURE_COOKIE_998877_ADMIN; HttpOnly')
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"Authentication Successful! Welcome Admin.")
            print("[SERVER] MFA Hop le! Da cap Session Cookie.")

print("[*] May chu that (Bank/Corp) dang chay tai 192.168.1.10:80...")
HTTPServer(('0.0.0.0', 80), AuthHandler).serve_forever()
