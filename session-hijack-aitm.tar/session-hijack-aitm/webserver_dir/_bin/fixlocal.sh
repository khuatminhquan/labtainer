#!/bin/bash
# Chạy ứng dụng Flask ngầm ở background
nohup python3 /usr/local/bin/app.py > /tmp/flask_error.log 2>&1 &
