from flask import Flask, request
import logging

app = Flask(__name__)

# File log vẫn ghi vào /var/log/webapp.log bình thường (vì fixlocal.sh chạy ngầm bằng quyền root)
logging.basicConfig(filename='/var/log/webapp.log', level=logging.INFO, format='%(message)s')

@app.route('/dashboard')
def dashboard():
    cookie = request.cookies.get('session_id')
    logging.info(f"GET /dashboard - Cookie: {cookie}")
    
    if cookie == "LIVE_STOLEN_COOKIE_9999":
        return "Welcome to Dashboard!", 200
    else:
        return "Unauthorized: Please login", 401

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
