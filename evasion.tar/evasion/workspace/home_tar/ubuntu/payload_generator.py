import base64

def advanced_encrypt(payload, key):
    # Lớp 1: Mã hóa XOR
    xor_bytes = [ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(payload)]
    
    # Lớp 2: Mã hóa Base64 mảng byte vừa tạo
    b64_encoded = base64.b64encode(bytes(xor_bytes)).decode('utf-8')
    return b64_encoded

if __name__ == "__main__":
    print("[*] Đang khởi tạo thuật toán mã hóa payload...")
    
    # Payload độc hại giả lập
    payload = "Write-Host 'You are hacked! - Advanced Lab 6'"
    key = "sec"
    
    encrypted_b64 = advanced_encrypt(payload, key)
    
    # Phân mảnh chuỗi Base64 thành các phần nhỏ (15 ký tự/mảnh) để giấu vào DOM
    chunk_size = 15
    chunks = [encrypted_b64[i:i+chunk_size] for i in range(0, len(encrypted_b64), chunk_size)]
    
    print("\n[+] Hoàn tất! Copy các dòng HTML dưới đây và dán vào file index.html của bạn:\n")
    for idx, chunk in enumerate(chunks):
        print(f'<div class="payload-chunk" data-index="{idx}" data-val="{chunk}" style="display:none;"></div>')
