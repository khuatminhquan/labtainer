#!/usr/bin/env python3
import subprocess
import sys

print("[*] Đang mô phỏng tấn công CEO Fraud (giả mạo IP gửi từ 10.0.0.99)...")

try:
    result = subprocess.run(['dig', '@127.0.0.1', '+short', 'TXT', 'company.com'], capture_output=True, text=True)
    output = result.stdout
    
    if 'v=spf1' in output:
        print("[!] Mail Server: 550 5.7.1 Giao dịch bị từ chối.")
        print("[+] Báo cáo Blue Team: Phòng thủ thành công! Lỗ hổng giả mạo bị chặn bởi SPF.")
    else:
        print("[+] Mail Server: 250 OK. Email giả mạo CEO đã được gửi đi!")
        print("[-] Cảnh báo: Lỗ hổng chưa được vá. Hãy cấu hình DNS!")
        
except Exception as e:
    print("Lỗi thực thi:", e)
