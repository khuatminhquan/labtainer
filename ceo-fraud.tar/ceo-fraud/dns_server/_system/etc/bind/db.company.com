$TTL    604800
@       IN      SOA     ns1.company.com. admin.company.com. (
                          2         ; Serial
                     604800         ; Refresh
                      86400         ; Retry
                    2419200         ; Expire
                     604800 )       ; Negative Cache TTL
;
@       IN      NS      ns1.company.com.
@       IN      MX  10  mail.company.com.
ns1     IN      A       192.168.1.10
mail    IN      A       192.168.1.20
www     IN      A       192.168.1.30
